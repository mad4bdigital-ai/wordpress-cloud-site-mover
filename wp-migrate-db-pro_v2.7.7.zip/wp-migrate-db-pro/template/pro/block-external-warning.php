<?php defined( 'ABSPATH' ) || exit; ?>
<p>
    <?php
    printf(__('We\'ve detected that <code>WP_HTTP_BLOCK_EXTERNAL</code> is enabled which will prevent WP Migrate from functioning properly. You should either disable <code>WP_HTTP_BLOCK_EXTERNAL</code> or add any sites that you\'d like to migrate to or from with WP Migrate to <code>WP_ACCESSIBLE_HOSTS</code> (api.deliciousbrains.com must be added to <code>WP_ACCESSIBLE_HOSTS</code> for the API to work). More information on this can be found <a href="%s" target="_blank">here</a>.',
        'wp-migrate-db'), 'https://deliciousbrains.com/wp-migrate-db-pro/doc/wp_http_block_external/?utm_campaign=error%2Bmessages&utm_source=MDB%2BPaid&utm_medium=insideplugin');
    ?>
</p>

